//задание 1

#include <iostream>

int main() {
    int N;
    std::cout << "Введите размер массива (N): ";
    std::cin >> N;

    // 1. Выделяем динамическую память под массив
    int* arr = new int[N];

    // 2. Заполняем числами от 1 до N
    for (int i = 0; i < N; ++i) {
        arr[i] = i + 1; // Индекс 0 -> значение 1
    }

    // 3. Выводим массив для проверки
    std::cout << "Массив: ";
    for (int i = 0; i < N; ++i) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;

    // 4. ОБЯЗАТЕЛЬНО освобождаем память!
    delete[] arr;

    return 0;
}

//задание 2

#include <iostream>

// Функция создает массив и возвращает сумму его элементов
int createArrayAndSum(int N) {
    // Выделяем память
    int* arr = new int[N];

    // Заполняем (например, от 1 до N)
    for (int i = 0; i < N; ++i) {
        arr[i] = i + 1;
    }

    // Считаем сумму
    int sum = 0;
    for (int i = 0; i < N; ++i) {
        sum += arr[i];
    }

    // Печатаем массив (для наглядности)
    std::cout << "Массив в функции: ";
    for (int i = 0; i < N; ++i) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;

    // Освобождаем память (функция сама удаляет, т.к. она выделяла)
    delete[] arr;

    // Возвращаем результат (число, не массив!)
    return sum;
}

int main() {
    int N;
    std::cout << "Введите N: ";
    std::cin >> N;

    int result = createArrayAndSum(N);
    std::cout << "Сумма элементов: " << result << std::endl;

    return 0;
}

// задание 3

#include <iostream>

int main() {
    int N, indexToDelete;

    // --- 1. Создаем исходный массив ---
    std::cout << "Введите размер массива: ";
    std::cin >> N;
    
    int* oldArr = new int[N];
    
    std::cout << "Введите " << N << " элементов: ";
    for (int i = 0; i < N; ++i) {
        std::cin >> oldArr[i];
    }

    // --- 2. Какой элемент удаляем? ---
    std::cout << "Введите индекс элемента для удаления (0 - " << N-1 << "): ";
    std::cin >> indexToDelete;

    // Проверка индекса
    if (indexToDelete < 0 || indexToDelete >= N) {
        std::cout << "Неверный индекс!" << std::endl;
        delete[] oldArr;
        return 1;
    }

    // --- 3. Создаем НОВЫЙ массив размером N-1 ---
    int* newArr = new int[N - 1];

    // --- 4. Копируем данные, пропуская удаляемый элемент ---
    for (int i = 0, j = 0; i < N; ++i) {
        if (i == indexToDelete) {
            continue; // Пропускаем этот элемент (не копируем)
        }
        newArr[j] = oldArr[i]; // Копируем в новое место
        j++; // Сдвигаем индекс нового массива только когда что-то положили
    }

    // --- 5. Вывод результата ---
    std::cout << "Новый массив после удаления: ";
    for (int i = 0; i < N - 1; ++i) {
        std::cout << newArr[i] << " ";
    }
    std::cout << std::endl;

    // --- 6. Очистка памяти ---
    delete[] oldArr; // Удалили старый
    delete[] newArr; // Удалили новый (в реальной программе его бы вернули наружу, но мы просто тестируем)

    return 0;
}