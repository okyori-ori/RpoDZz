// задание 1

#include <iostream>

// Функция возвращает ССЫЛКУ на максимальный элемент массива
int& findMaxRef(int arr[], int size) {
    if (size <= 0) {
        // Обработка ошибки: возвращаем первый элемент (хотя лучше исключение)
        // Но в учебных целях просто выведем предупреждение
        std::cerr << "Массив пуст!" << std::endl;
        return arr[0]; // Рискованно, но пусть будет
    }

    int maxIndex = 0;
    for (int i = 1; i < size; ++i) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
        }
    }
    // Возвращаем ссылку на элемент (не просто его значение!)
    return arr[maxIndex];
}

int main() {
    int arr[] = {5, 3, 8, 1, 9, 2};
    int size = sizeof(arr) / sizeof(arr[0]);

    std::cout << "Исходный массив: ";
    for (int x : arr) std::cout << x << " ";
    std::cout << std::endl;

    // 1. Используем функцию, чтобы узнать максимум
    int maxValue = findMaxRef(arr, size); // Здесь возвращенное значение копируется в maxValue
    std::cout << "Максимум: " << maxValue << std::endl;

    // 2. Используем функцию, чтобы ИЗМЕНИТЬ максимум через ссылку
    findMaxRef(arr, size) = 999; // Самое интересное!

    std::cout << "Массив после изменения максимума: ";
    for (int x : arr) std::cout << x << " ";
    std::cout << std::endl;

    return 0;
}

//задание 2

#include <iostream>
#include <cstdlib>  // для rand()
#include <ctime>    // для time()

// Функция 1: Возвращает ссылку на минимальный элемент
int& minRef(int arr[], int size) {
    int minIndex = 0;
    for (int i = 1; i < size; ++i) {
        if (arr[i] < arr[minIndex]) {
            minIndex = i;
        }
    }
    return arr[minIndex];
}

// Функция 2: Возвращает ссылку на максимальный элемент
int& maxRef(int arr[], int size) {
    int maxIndex = 0;
    for (int i = 1; i < size; ++i) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
        }
    }
    return arr[maxIndex];
}

// Функция 3: Нормализация (min -> 0, max -> 100)
void normalize(int arr[], int size) {
    // Получаем значения минимума и максимума
    int minVal = minRef(arr, size); // Просто берем значение
    int maxVal = maxRef(arr, size);

    std::cout << "До нормализации: min = " << minVal << ", max = " << maxVal << std::endl;

    // Если все числа одинаковые, чтобы не делить на ноль
    if (maxVal == minVal) {
        std::cout << "Все элементы равны. Нормализация невозможна." << std::endl;
        return;
    }

    // Проходим по массиву и линейно преобразуем каждый элемент
    for (int i = 0; i < size; ++i) {
        // Формула приведения диапазона [minVal, maxVal] к [0, 100]
        arr[i] = (arr[i] - minVal) * 100 / (maxVal - minVal);
    }

    // ГАРАНТИРОВАННО устанавливаем min и max через ссылки (на случай погрешности целочисленного деления)
    minRef(arr, size) = 0;   // Изменяем оригинал через ссылку
    maxRef(arr, size) = 100; // Изменяем оригинал через ссылку
}

int main() {
    // Инициализация генератора случайных чисел
    srand(time(0));
    const int SIZE = 15;
    int arr[SIZE];

    // Заполняем массив случайными числами от 0 до 99
    for (int i = 0; i < SIZE; ++i) {
        arr[i] = rand() % 100;
    }

    // Вывод исходного массива
    std::cout << "Исходный массив: ";
    for (int i = 0; i < SIZE; ++i) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;

    // Вызов функции нормализации
    normalize(arr, SIZE);
ы
    // Вывод результата
    std::cout << "После нормализации: ";
    for (int i = 0; i < SIZE; ++i) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;

    // Проверка: выведем min и max через функции
    std::cout << "Минимум теперь: " << minRef(arr, SIZE) << std::endl;
    std::cout << "Максимум теперь: " << maxRef(arr, SIZE) << std::endl;

    return 0;
}