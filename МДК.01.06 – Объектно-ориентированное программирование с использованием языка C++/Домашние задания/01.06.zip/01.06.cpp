#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>
#include <chrono>

int main() {
    const int SIZE = 1000000;
    std::vector<int> vec(SIZE);
    std::iota(vec.begin(), vec.end(), 1);

    auto start_reverse = std::chrono::high_resolution_clock::now();
    std::reverse(vec.begin(), vec.end());
    auto end_reverse = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> duration_reverse = end_reverse - start_reverse;

    auto start_sort = std::chrono::high_resolution_clock::now();
    std::sort(vec.begin(), vec.end());
    auto end_sort = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> duration_sort = end_sort - start_sort;

    std::cout << "Reverse time: " << duration_reverse.count() << " ms" << std::endl;
    std::cout << "Sort time: " << duration_sort.count() << " ms" << std::endl;

    return 0;
}