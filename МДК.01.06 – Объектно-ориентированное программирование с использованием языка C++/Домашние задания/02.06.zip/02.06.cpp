#include <iostream>
#include <fstream>
#include <string>

int main() {
    std::ifstream inFile("data.txt");
    if (!inFile.is_open()) {
        std::cerr << "Error opening input file data.txt" << std::endl;
        return 1;
    }

    std::string line;
    int lineCount = 0;
    int charCount = 0;

    while (std::getline(inFile, line)) {
        lineCount++;
        charCount += line.length(); 
    }
    inFile.close();

    std::ofstream outFile("result.txt");
    if (!outFile.is_open()) {
        std::cerr << "Error opening output file result.txt" << std::endl;
        return 1;
    }

    outFile << "Lines: " << lineCount << std::endl;
    outFile << "Characters: " << charCount << std::endl;
    outFile.close();

    std::cout << "Analysis complete. Results written to result.txt" << std::endl;
    return 0;
}