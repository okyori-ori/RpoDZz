#include <iostream>

class Device {
public:
    void turnOn() {
        std::cout << "Device is turned ON." << std::endl;
    }

    void turnOff() {
        std::cout << "Device is turned OFF." << std::endl;
    }
};

class Light : public Device {
public:
    void turnOn() {
        std::cout << "Light is now ON (bright)." << std::endl;
    }

    void turnOff() {
        std::cout << "Light is now OFF." << std::endl;
    }
};

class Thermostat : private Device {
public:
    void turnOn() {
        std::cout << "Thermostat system activated." << std::endl;
    }

    void turnOff() {
        std::cout << "Thermostat system deactivated." << std::endl;
    }

    void testInternalAccess() {
        Device::turnOn();
        Device::turnOff();
    }
};

int main() {
    Light myLight;
    myLight.turnOn();
    myLight.Device::turnOn();
    myLight.turnOff();

    Thermostat myThermostat;
    myThermostat.turnOn();
    myThermostat.turnOff();
    
    myThermostat.testInternalAccess();

    return 0;
}