#include <iostream>
#include <stdexcept>

class Array {
private:
    int data[5];

public:
    Array() {
        for (int i = 0; i < 5; ++i) {
            data[i] = 0;
        }
    }

    int& operator[](int index) {
        if (index < 0 || index >= 5) {
            throw std::out_of_range("Index out of bounds");
        }
        return data[index];
    }

    const int& operator[](int index) const {
        if (index < 0 || index >= 5) {
            throw std::out_of_range("Index out of bounds");
        }
        return data[index];
    }
};

class Count {
private:
    int value;

public:
    Count() {
        value = 0;
    }

    Count(int val) {
        value = val;
    }

    Count& operator++() {
        ++value;
        return *this;
    }

    Count operator++(int) {
        Count temp = *this;
        ++value;
        return temp;
    }

    Count& operator--() {
        --value;
        return *this;
    }

    Count operator--(int) {
        Count temp = *this;
        --value;
        return temp;
    }

    int getValue() const {
        return value;
    }
};

int main() {
    try {
        Array arr;
        arr[0] = 10;
        arr[4] = 50;
        std::cout << "Array[0]: " << arr[0] << ", Array[4]: " << arr[4] << std::endl;
        arr[5] = 100;
    } catch (const std::out_of_range& e) {
        std::cout << "Exception caught: " << e.what() << std::endl;
    }

    Count c(10);
    
    Count prefixInc = ++c;
    std::cout << "Prefix ++: c = " << c.getValue() << ", result = " << prefixInc.getValue() << std::endl;

    Count postfixInc = c++;
    std::cout << "Postfix ++: c = " << c.getValue() << ", result = " << postfixInc.getValue() << std::endl;

    Count prefixDec = --c;
    std::cout << "Prefix --: c = " << c.getValue() << ", result = " << prefixDec.getValue() << std::endl;

    Count postfixDec = c--;
    std::cout << "Postfix --: c = " << c.getValue() << ", result = " << postfixDec.getValue() << std::endl;

    return 0;
}