#include <iostream>

class Point {
private:
    int x;
    int y;

public:
    Point() {
        x = 0;
        y = 0;
    }

    Point(int xVal, int yVal) {
        x = xVal;
        y = yVal;
    }

    Point operator+(const Point& other) {
        return Point(x + other.x, y + other.y);
    }

    Point operator-(const Point& other) {
        return Point(x - other.x, y - other.y);
    }

    bool operator==(const Point& other) {
        return (x == other.x && y == other.y);
    }

    friend std::ostream& operator<<(std::ostream& os, const Point& point) {
        os << "(" << point.x << ", " << point.y << ")";
        return os;
    }
};

int main() {
    Point p1(10, 20);
    Point p2(5, 5);

    Point p3 = p1 + p2;
    Point p4 = p1 - p2;

    std::cout << "p1 + p2 = " << p3 << std::endl;
    std::cout << "p1 - p2 = " << p4 << std::endl;

    if (p1 == p2) {
        std::cout << "Points are equal" << std::endl;
    } else {
        std::cout << "Points are not equal" << std::endl;
    }

    return 0;
}