#include <iostream>
#include <thread>
#include <chrono>

void printNumbers() {
    for (int i = 1; i <= 5; ++i) {
        std::cout << i << " ";
        // Небольшая задержка, чтобы вывод потоков перемешивался нагляднее
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
}

void printLetters() {
    for (char c = 'A'; c <= 'E'; ++c) {
        std::cout << c << " ";
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
}

int main() {
    // Создание и запуск двух потоков параллельно
    std::thread t1(printNumbers);
    std::thread t2(printLetters);

    // Главный поток дожидается завершения обоих потоков
    t1.join();
    t2.join();

    std::cout << "\nBoth threads have finished execution." << std::endl;

    return 0;
}