class Book {
private:
    std::string title;
    int pages;

public:
    Book() {
        title = "Unknown";
        pages = 0;
    }

    Book(std::string bookTitle, int bookPages) {
        title = bookTitle;
        pages = bookPages;
    }

    void display() {
        std::cout << "Title: " << title << ", Pages: " << pages << std::endl;
    }
};

class DynamicBuffer {
private:
    int* buffer;
    int size;

public:
    DynamicBuffer(int bufferSize) {
        size = bufferSize;
        buffer = new int[size];
    }

    ~DynamicBuffer() {
        delete[] buffer;
    }

    void fill(int value) {
        for (int i = 0; i < size; ++i) {
            buffer[i] = value;
        }
    }
};

int main() {
    Book book1;
    Book book2("C++ Programming", 450);

    book1.display();
    book2.display();

    DynamicBuffer myBuffer(5);
    myBuffer.fill(10);

    return 0;
}