#include <iostream>
#include <string>

class Processor {
private:
    std::string model;

public:
    Processor(std::string procModel) : model(procModel) {}

    void start() {
        std::cout << "Processor " << model << " started." << std::endl;
    }
};

class RAM {
private:
    int size;

public:
    RAM(int ramSize) : size(ramSize) {}

    void start() {
        std::cout << "RAM " << size << "GB started." << std::endl;
    }
};

class GPU {
private:
    std::string model;

public:
    GPU(std::string gpuModel) : model(gpuModel) {}

    void start() {
        std::cout << "GPU " << model << " started." << std::endl;
    }
};

class Computer {
private:
    Processor processor;
    RAM ram;
    GPU gpu;

public:
    Computer(std::string procModel, int ramSize, std::string gpuModel)
        : processor(procModel), ram(ramSize), gpu(gpuModel) {}

    void start() {
        std::cout << "Starting computer system..." << std::endl;
        processor.start();
        ram.start();
        gpu.start();
        std::cout << "Computer system is ready." << std::endl;
    }
};

int main() {
    Computer myComputer("Intel i7", 16, "NVIDIA RTX 4060");
    myComputer.start();

    return 0;
}