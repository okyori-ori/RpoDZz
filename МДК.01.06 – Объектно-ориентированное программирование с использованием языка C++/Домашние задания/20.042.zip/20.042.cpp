#include <iostream>
#include <string>

class Employee {
protected:
    std::string name;

public:
    Employee(std::string empName) : name(empName) {}

    virtual void work() {
        std::cout << name << " is doing general work." << std::endl;
    }

    virtual ~Employee() {}
};

class Manager : public Employee {
public:
    Manager(std::string empName) : Employee(empName) {}

    void work() override {
        std::cout << name << " is managing the team and scheduling tasks." << std::endl;
    }

    void manage() {
        std::cout << name << " is holding a meeting." << std::endl;
    }
};

class Developer : public Employee {
public:
    Developer(std::string empName) : Employee(empName) {}

    void work() override {
        std::cout << name << " is writing and reviewing code." << std::endl;
    }

    void code() {
        std::cout << name << " is fixing bugs." << std::endl;
    }
};

int main() {
    Employee* emp1 = new Manager("Alice");
    Employee* emp2 = new Developer("Bob");

    emp1->work();
    emp2->work();

    Manager* mgr = dynamic_cast<Manager*>(emp1);
    if (mgr != nullptr) {
        mgr->manage();
    }

    Developer* dev = dynamic_cast<Developer*>(emp2);
    if (dev != nullptr) {
        dev->code();
    }

    delete emp1;
    delete emp2;

    return 0;
}