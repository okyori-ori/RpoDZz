#include <iostream>
#include <fstream>
#include <string>

class FileWrapper {
private:
    std::ofstream file;

public:
    FileWrapper(const std::string& filename) {
        file.open(filename);
    }

    ~FileWrapper() {
        if (file.is_open()) {
            file.close();
        }
    }

    void write(const std::string& text) {
        if (file.is_open()) {
            file << text << std::endl;
        }
    }
};

class DynamicArray {
private:
    int* data;
    int size;

public:
    DynamicArray(int arraySize) {
        size = arraySize;
        data = new int[size];
        for (int i = 0; i < size; ++i) {
            data[i] = 0;
        }
    }

    ~DynamicArray() {
        delete[] data;
    }

    void set(int index, int value) {
        if (index >= 0 && index < size) {
            data[index] = value;
        }
    }

    int get(int index) const {
        if (index >= 0 && index < size) {
            return data[index];
        }
        return 0;
    }
};

int main() {
    FileWrapper fw("test.txt");
    fw.write("Hello, World!");

    DynamicArray arr(5);
    arr.set(0, 100);
    std::cout << "Element 0: " << arr.get(0) << std::endl;

    return 0;
}