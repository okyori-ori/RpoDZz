#include <iostream>
#include <string>

class Teacher {
private:
    std::string name;

public:
    Teacher(std::string teacherName) : name(teacherName) {}

    std::string getName() const {
        return name;
    }
};

class Course {
private:
    const Teacher* teacher;
    std::string courseName;

public:
    Course(std::string name, const Teacher* courseTeacher) : courseName(name), teacher(courseTeacher) {}

    void displayTeacher() const {
        if (teacher != nullptr) {
            std::cout << "Course: " << courseName << ", Teacher: " << teacher->getName() << std::endl;
        } else {
            std::cout << "Course: " << courseName << ", No teacher assigned." << std::endl;
        }
    }
};

int main() {
    Teacher teacher1("Dr. Smith");
    
    Course course1("Object-Oriented Programming", &teacher1);
    course1.displayTeacher();

    return 0;
}