#include <iostream>
#include <thread>
#include <mutex>
#include <chrono>
#include <vector>

const int ITERATIONS = 100000;
int counter = 0;
std::mutex mtx;

// Функция без синхронизации (Race Condition)
void incrementUnsynced() {
    for (int i = 0; i < ITERATIONS; ++i) {
        counter++; 
    }
}

// Функция с синхронизацией через mutex
void incrementSynced() {
    for (int i = 0; i < ITERATIONS; ++i) {
        mtx.lock();
        counter++;
        mtx.unlock();
    }
}

int main() {
    // --- 1. Запуск без синхронизации ---
    counter = 0;
    auto start_unsynced = std::chrono::high_resolution_clock::now();

    std::thread t1(incrementUnsynced);
    std::thread t2(incrementUnsynced);
    t1.join();
    t2.join();

    auto end_unsynced = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> time_unsynced = end_unsynced - start_unsynced;

    std::cout << "[ Without Synchronization ]" << std::endl;
    std::cout << "Expected Counter: " << ITERATIONS * 2 << std::endl;
    std::cout << "Actual Counter:   " << counter << std::endl;
    std::cout << "Execution Time:   " << time_unsynced.count() << " ms" << std::endl;
    std::cout << "--------------------------------" << std::endl;

    // --- 2. Запуск с использованием mutex ---
    counter = 0;
    auto start_synced = std::chrono::high_resolution_clock::now();

    std::thread t3(incrementSynced);
    std::thread t4(incrementSynced);
    t3.join();
    t4.join();

    auto end_synced = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> time_synced = end_synced - start_synced;

    std::cout << "[ With Mutex Synchronization ]" << std::endl;
    std::cout << "Expected Counter: " << ITERATIONS * 2 << std::endl;
    std::cout << "Actual Counter:   " << counter << std::endl;
    std::cout << "Execution Time:   " << time_synced.count() << " ms" << std::endl;

    return 0;
}