#include <iostream>
#include <fstream>
#include <filesystem>

namespace fs = std::filesystem;

int main() {
    fs::path dirPath = "test_folder";
    fs::path filePath = dirPath / "data.txt";

    // 1. Проверяем существование папки, если нет — создаём
    if (!fs::exists(dirPath)) {
        if (fs::create_directory(dirPath)) {
            std::cout << "Directory 'test_folder' successfully created." << std::endl;
        } else {
            std::cerr << "Failed to create directory." << std::endl;
            return 1;
        }
    } else {
        std::cout << "Directory 'test_folder' already exists." << std::endl;
    }

    // 2. Создаём файл и записываем произвольный текст
    std::ofstream outFile(filePath);
    if (outFile.is_open()) {
        outFile << "This is some sample text inside data.txt" << std::endl;
        outFile << "File handling using std::filesystem." << std::endl;
        outFile.close();
        std::cout << "File 'data.txt' created and written to successfully." << std::endl;
    } else {
        std::cerr << "Failed to create file." << std::endl;
        return 1;
    }

    // 3. Выводим список всех файлов и папок внутри test_folder
    std::cout << "\nContents of 'test_folder':" << std::endl;
    if (fs::exists(dirPath) && fs::is_directory(dirPath)) {
        for (const auto& entry : fs::directory_iterator(dirPath)) {
            std::cout << " - " << entry.path().filename().string();
            if (fs::is_directory(entry.path())) {
                std::cout << " [Directory]";
            } else if (fs::is_regular_file(entry.path())) {
                std::cout << " [File]";
            }
            std::cout << std::endl;
        }
    }

    return 0;
}