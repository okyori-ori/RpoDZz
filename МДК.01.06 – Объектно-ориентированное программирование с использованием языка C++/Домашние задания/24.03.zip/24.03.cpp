#include <iostream>
#include <cstring>

class String {
private:
    char* data;

public:
    String() {
        data = new char[1];
        data[0] = '\0';
    }

    String(const char* str) {
        if (str == nullptr) {
            data = new char[1];
            data[0] = '\0';
        }
        else {
            data = new char[std::strlen(str) + 1];
            std::strcpy(data, str);
        }
    }

    String(const String& other) {
        data = new char[std::strlen(other.data) + 1];
        std::strcpy(data, other.data);
    }

    String& operator=(const String& other) {
        if (this != &other) {
            delete[] data;
            data = new char[std::strlen(other.data) + 1];
            std::strcpy(data, other.data);
        }
        return *this;
    }

    ~String() {
        delete[] data;
    }

    void print() const {
        std::cout << data << std::endl;
    }
};class Buffer {
private:
    int* data;
    int size;

public:
    Buffer(int bufferSize) {
        size = bufferSize;
        data = new int[size];
        for (int i = 0; i < size; ++i) {
            data[i] = 0;
        }
    }

    Buffer(const Buffer& other) {
        size = other.size;
        data = new int[size];
        for (int i = 0; i < size; ++i) {
            data[i] = other.data[i];
        }
    }

    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            delete[] data;
            size = other.size;
            data = new int[size];
            for (int i = 0; i < size; ++i) {
                data[i] = other.data[i];
            }
        }
        return *this;
    }

    ~Buffer() {
        delete[] data;
    }

    void set(int index, int value) {
        if (index >= 0 && index < size) {
            data[index] = value;
        }
    }

    void print() const {
        for (int i = 0; i < size; ++i) {
            std::cout << data[i] << " ";
        }
        std::cout << std::endl;
    }
};

int main() {
    String s1("Hello");
    String s2 = s1;
    String s3;
    s3 = s2;

    s1.print();
    s2.print();
    s3.print();

    Buffer b1(5);
    b1.set(0, 10);
    b1.set(1, 20);

    Buffer b2 = b1;
    Buffer b3(3);
    b3 = b1;

    b1.print();
    b2.print();
    b3.print();

    return 0;
}