#include <iostream>
#include <string>

class Character {
protected:
    std::string name;

public:
    Character(std::string charName) : name(charName) {}

    virtual void attack() {
        std::cout << name << " basic attacks." << std::endl;
    }

    virtual ~Character() {}
};

class Warrior : public Character {
public:
    Warrior(std::string charName) : Character(charName) {}

    void attack() override {
        std::cout << name << " attacks with a heavy sword!" << std::endl;
    }

    void slash() {
        std::cout << name << " performs a powerful slash!" << std::endl;
    }
};

class Mage : public Character {
public:
    Mage(std::string charName) : Character(charName) {}

    void attack() override {
        std::cout << name << " fires a magic missile!" << std::endl;
    }

    void castSpell() {
        std::cout << name << " casts a fireball spell!" << std::endl;
    }
};

int main() {
    Warrior warrior("Thorin");
    Mage mage("Gandalf");

    warrior.attack();
    warrior.slash();

    mage.attack();
    mage.castSpell();

    return 0;
}