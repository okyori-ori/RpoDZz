#include <iostream>
#include <string>

enum ClothesType {
    T_SHIRT,
    PANTS,
    JACKET,
    DRESS
};

class Clothes {
private:
    ClothesType type;
    std::string name;
    double price;
    std::string size;
    std::string color;

public:
    Clothes(ClothesType cType, std::string cName, double cPrice, std::string cSize, std::string cColor) {
        type = cType;
        name = cName;
        price = cPrice;
        size = cSize;
        color = cColor;
    }

    std::string getName() {
        return name;
    }

    void setName(std::string cName) {
        name = cName;
    }

    double getPrice() {
        return price;
    }

    void setPrice(double cPrice) {
        price = cPrice;
    }

    ClothesType getCategory() {
        return type;
    }

    void setCategory(ClothesType cType) {
        type = cType;
    }
};

class Student {
private:
    static int count;

public:
    Student() {
        count++;
    }

    static int getCount() {
        return count;
    }
};

int Student::count = 0;

int main() {
    Clothes item(JACKET, "Winter Parka", 129.99, "XL", "Black");
    std::cout << "Clothes - Name: " << item.getName() << ", Price: " << item.getPrice() << ", Type: " << item.getCategory() << std::endl;
    
    item.setName("Light Jacket");
    item.setPrice(89.99);
    std::cout << "Clothes Updated - Name: " << item.getName() << ", Price: " << item.getPrice() << std::endl;

    std::cout << "Student Initial count: " << Student::getCount() << std::endl;
    Student s1;
    Student s2;
    Student s3;
    std::cout << "Student Count after creating 3 students: " << Student::getCount() << std::endl;

    return 0;
}